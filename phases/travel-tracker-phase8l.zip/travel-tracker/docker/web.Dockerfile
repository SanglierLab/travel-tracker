# Contexte de build : la racine du dépôt (voir docker-compose.yml)

FROM node:24-alpine AS build
WORKDIR /build
COPY frontend/package.json frontend/package-lock.json ./
RUN npm ci
COPY frontend/ .
RUN npm run build

FROM nginx:stable-alpine
COPY docker/nginx.conf /etc/nginx/conf.d/default.conf
# Rotation des journaux d'accès : script de compression/purge + lancement de cron au démarrage du conteneur.
COPY docker/rotate-logs.sh /usr/local/bin/rotate-logs.sh
COPY docker/40-log-rotation.sh /docker-entrypoint.d/40-log-rotation.sh
RUN chmod +x /usr/local/bin/rotate-logs.sh /docker-entrypoint.d/40-log-rotation.sh \
    && sed -i 's/\r$//' /usr/local/bin/rotate-logs.sh /docker-entrypoint.d/40-log-rotation.sh
COPY --from=build /build/dist /usr/share/nginx/html
